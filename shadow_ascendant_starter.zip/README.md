# Shadow Ascendant — mobile game starter

A small HTML5 action-game prototype with:
- Touch joystick, attack, and shadow burst controls
- Offline monster AI, XP, levels, health, and restart after defeat
- Experimental peer-to-peer online rooms using PeerJS/WebRTC
- PWA manifest and service worker for installable browser experience

## Important project status
This is a **prototype**, not a finished commercial game. Online mode is a lightweight peer-to-peer demo, not a secure authoritative multiplayer backend. It may fail on some networks and does not yet include matchmaking, accounts, persistence, anti-cheat, moderation, or dedicated servers.

The files use the original placeholder title **Shadow Ascendant**. “Solo Leveling” and its characters/world/art are protected intellectual property. Before publishing publicly under that franchise name or using its official characters, logos, music, or art, get permission from the rights holder. Safer route: publish with your own original title, characters, and artwork.

## Start on an Android phone
You do not need a PC for the first web release.

1. Download and extract this ZIP using your Android file manager.
2. Create a GitHub account if needed and sign in in Chrome.
3. Open https://github.com/new and create a **public** repository, e.g. `shadow-ascendant`.
4. In the repository choose **Add file → Upload files**. Upload `index.html`, `manifest.json`, `sw.js`, `icon.svg`, and this README from the extracted folder. Commit the files.
5. In repository **Settings → Pages**, set deployment to **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to show the live site URL. Open it in Chrome on your phone and test controls. HTTPS is required for PWA install and online browser APIs.
7. For a second device, open the same URL. On the host device tap **HOST ONLINE** and share the room code. On the other device tap **JOIN** and enter the code. Both players need internet; the connection can fail on restrictive networks.

## Install it on your Android phone (PWA)
1. Open the published HTTPS URL in Chrome.
2. Open Chrome's three-dot menu and choose **Install app** or **Add to Home screen** (wording varies).
3. Launch it from the new home-screen icon. This installs the website as a PWA, not a Play Store APK.

## Make an Android APK/AAB without a PC
A PWA is the easiest first mobile install. To create an Android package, try https://www.pwabuilder.com after the website is live:
1. Enter your HTTPS GitHub Pages URL and run the checks.
2. Follow its Android package workflow if available. Store publishing may require a signed AAB, developer account, privacy policy, screenshots, and compliance with current store rules.
3. Test the package on your phone before sharing. If the service requires a build/signing step that cannot be completed on your phone, you will need a trusted cloud build or access to a computer. Never share signing keys or account passwords.

## Publish on a game website
- **itch.io:** create a project, choose HTML, upload a ZIP containing `index.html`, `manifest.json`, `sw.js`, and `icon.svg`, and enable “This file will be played in the browser.” Test the embedded page; if external CDNs are blocked, host the game on GitHub Pages and link to it.
- **GitHub Pages:** good for the live browser version and phone testing.
- Other web-game portals have their own review, content, and packaging rules.

## How to customize
- Change the visible title in `index.html` and `manifest.json`.
- Adjust enemy health, spawn rate, player speed, and attack values in `index.html`.
- Replace `icon.svg` with your own original icon. Keep all art/audio you publish licensed or self-created.
- PeerJS is loaded from a CDN, so internet is needed for the multiplayer library. Offline mode itself is designed to run without a connection after the page has loaded and been cached.

## Suggested next development milestones
1. Add original sprites, animation, sound, menus, and settings.
2. Improve mobile testing and accessibility.
3. Build a proper backend for accounts, lobbies, authoritative combat, reconnects, and anti-cheat before competitive multiplayer.
4. Add privacy policy and age/content/store disclosures if collecting any data.
5. Test on multiple Android devices and browsers before public release.
