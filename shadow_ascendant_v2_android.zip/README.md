# Shadow Ascendant v2 — Android-first game prototype

## What's upgraded
- Anime-inspired arena backdrop, layered mountain silhouettes and glowing particles
- Stylized shadow enemies, elite enemy variant, hit sparks, aura, strike arc, screen shake
- Mobile joystick plus Strike, Shadow Burst, and Flash Step controls
- XP, levels, health, offline survival and experimental peer-to-peer room codes
- PWA manifest and offline cache

## Publish the browser version
1. Extract this ZIP on your Android phone.
2. In Chrome, create a GitHub account/repository at https://github.com/new
3. Upload `index.html`, `manifest.json`, `sw.js`, `icon.svg` to the repository root.
4. Open Settings → Pages; choose Deploy from a branch, `main`, `/ (root)` and Save.
5. Wait for GitHub Pages to publish your HTTPS URL, then open and test it.

## Installable Android app (phone-only path)
The simplest install is a PWA:
1. Open the HTTPS GitHub Pages URL in Chrome.
2. Chrome menu ⋮ → Install app / Add to Home screen.

For an APK to test or an AAB for Google Play:
1. Publish the site first; PWABuilder requires a public HTTPS PWA and web manifest.
2. Visit https://www.pwabuilder.com and enter the published URL.
3. Choose Package for stores → Android → Generate Package. Configure app name, package ID, version and signing.
4. Download the package ZIP. It normally contains an APK for device testing and an AAB for Play Store submission; follow the current service prompts.
5. Extract the ZIP on your phone. Tap the APK to install it. Android may ask you to allow installs from that browser/file manager; only do this for the package you just generated from your own project. Turn the permission back off afterward if desired.
6. If using the AAB, upload it to Play Console instead; an AAB is not directly installable by tapping it.
7. Follow the generated package's instructions for publishing `/.well-known/assetlinks.json`. If the links are wrong, the app may show a browser bar or fail to open correctly.

PWABuilder packages the website as an Android Trusted Web Activity. It is not a fully native game engine build. A computer is not required for the standard cloud packaging flow, but a desktop/cloud build may be needed if a service changes or a signing step cannot be completed on mobile.

## Multiplayer caveat
Online co-op is an experimental PeerJS/WebRTC prototype, not a production backend. It has no accounts, secure authoritative combat, moderation, or guaranteed connectivity. Test on two phones on different networks. Offline play is the main reliable mode.

## Franchise/IP
“Solo Leveling” is a protected franchise. This project uses the original placeholder name Shadow Ascendant. For public release, use original characters, branding, music and artwork unless you have permission to use franchise materials.

## Before publishing
- Test on more than one Android browser/device.
- Keep your signing key private and backed up; never share it.
- Make an original privacy policy if you collect any personal data.
- Review the current Play Console requirements. New personal developer accounts may need a closed test with at least 12 opted-in testers for 14 continuous days before production access.
